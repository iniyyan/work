function validate(){
	 var regexForQuestions="^[a-zA-Z .,']+[?]$";
	 var Q=document.getElementById("question").value;
	 var i=0;
	 if(Q==""||!(Q.match(regexForQuestions))||!(Q.length<=30)){
         document.getElementById("questionerror").innerHTML="Enter a valid question";
         i+=1;
     }else{
         document.getElementById("questionerror").innerHTML="";
     }
	 if(i==0){
		 return true;
	 }
	 return false;
}