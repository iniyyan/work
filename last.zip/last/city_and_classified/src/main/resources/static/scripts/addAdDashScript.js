function validate(){
	var title=document.getElementById("i").value;
	console.log(title);
	var category=document.getElementById("category").value;
	var field1=document.getElementById("field1").value;
	var field2=document.getElementById("field2").value;
	var img=document.getElementById("img").value;
	var i=0;
	if(title==""){
        document.getElementById("titleerror").innerHTML="Enter a valid title";
        i+=1;
    }else{
        document.getElementById("titleerror").innerHTML="";
    }
	if(category==""){
        document.getElementById("errorcategory").innerHTML="Enter a valid category";
        i+=1;
    }else{
        document.getElementById("errorcategory").innerHTML="";
    }
	if(field1==""){
        document.getElementById("errorfield1").innerHTML="This field is mandatory";
        i+=1;
    }else{
        document.getElementById("errorfield1").innerHTML="";
    }if(field2==""){
        document.getElementById("errorfield2").innerHTML="This field is mandatory";
        i+=1;
    }else{
        document.getElementById("errorfield2").innerHTML="";
    }if(img==""){
        document.getElementById("errorimg").innerHTML="Please select a image";
        i+=1;
    }else{
        document.getElementById("errorimg").innerHTML="";
    }
    if(i==0){
		 return true;
	 }
	 return false;
}