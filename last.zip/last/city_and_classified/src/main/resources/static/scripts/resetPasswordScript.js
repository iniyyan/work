function validate(){
 var regexForPassword="(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{6,})";
  var password=document.getElementById("password").value;
  var repassword=document.getElementById("rePassword").value;
  var i=0;

  if(!(password.match(regexForPassword))){
    document.getElementById("errorpassword").innerHTML="Enter a valid Password";
    i+=1;
 }else{
    document.getElementById("errorpassword").innerHTML="";


  }
  
  if(!(repassword.match(regexForPassword)))
	  {
	  document.getElementById("errorrepassword").innerHTML="Enter a valid Password";
	  i=i+1;
	  }
  else{
	  document.getElementById("errorrepassword").innerHTML="";
  }
  
  
  if(!(password==repassword)){
   document.getElementById("errorrepassword").innerHTML="Reset Password does not match password";
     i+=1;
  }else{
    document.getElementById("errorrepassword").innerHTML="";

  }if(i==0){
   return true;
  }
  return false;
}