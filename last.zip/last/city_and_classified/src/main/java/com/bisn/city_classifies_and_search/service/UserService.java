package com.bisn.city_classifies_and_search.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import org.apache.catalina.mapper.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.bisn.city_classifies_and_search.model.Advertisement;
import com.bisn.city_classifies_and_search.model.Feedback;
import com.bisn.city_classifies_and_search.model.Login;
import com.bisn.city_classifies_and_search.model.User;
import com.mysql.jdbc.Blob;

@Service
public class UserService {
	@Autowired
	JdbcTemplate jdbcTemplate;

	public int updateuser(boolean role, int id) {

		PreparedStatementCreator admin = new PreparedStatementCreator() {

			@Override
			public java.sql.PreparedStatement createPreparedStatement(java.sql.Connection con) throws SQLException {
				java.sql.PreparedStatement query = con
						.prepareStatement("update roles set e_req=1,e_role='admin' where e_id=?");
				query.setInt(1, id);
				return query;
			}
		};
		PreparedStatementCreator invalid = new PreparedStatementCreator() {

			@Override
			public java.sql.PreparedStatement createPreparedStatement(java.sql.Connection con) throws SQLException {
				java.sql.PreparedStatement query = con
						.prepareStatement("update roles set e_req=-1,e_role='invalid' where e_id=?");
				query.setInt(1, id);
				return query;
			}
		};

		if (role == true) {
			return jdbcTemplate.update(admin);
		}
		if (role == false) {
			return jdbcTemplate.update(invalid);
		}
		return 1;
	}

	public void updateRegister(User user, Login login) {
		try {

			int userId = user.getId();
			String firstName = user.getFirstName();
			String lastname = user.getLastName();
			String email = user.getEmail();
			String password = user.getPassword();
			String admin = "adminreq";
			String roles = "user";
			String Q1=user.getQ1();
			String Q2=user.getQ2();
			String Q3=user.getQ3();

			PreparedStatementCreator updateRegister_True = new PreparedStatementCreator() {

				@Override
				public java.sql.PreparedStatement createPreparedStatement(java.sql.Connection con) throws SQLException {
					java.sql.PreparedStatement query = con
							.prepareStatement("insert into register values(?,?,?,?," + true + ",?,?,?,?)");
					query.setInt(1, userId);
					query.setString(2, firstName);
					query.setString(3, lastname);
					query.setString(4, email);
					query.setString(5, password);
					query.setString(6, Q1);
					query.setString(7, Q2);
					query.setString(8, Q3);

					return query;
				}
			};

			PreparedStatementCreator updateRegister_false = new PreparedStatementCreator() {

				@Override
				public java.sql.PreparedStatement createPreparedStatement(java.sql.Connection con) throws SQLException {
					java.sql.PreparedStatement query = con
							.prepareStatement("insert into register values(?,?,?,?," + false + ",?,?,?,?)");
					query.setInt(1, userId);
					query.setString(2, firstName);
					query.setString(3, lastname);
					query.setString(4, email);
					query.setString(5, password);
					query.setString(6, Q1);
					query.setString(7, Q2);
					query.setString(8, Q3);

					return query;
				}
			};

			PreparedStatementCreator roles_admin = new PreparedStatementCreator() {

				@Override
				public java.sql.PreparedStatement createPreparedStatement(java.sql.Connection con) throws SQLException {
					java.sql.PreparedStatement query = con.prepareStatement("insert into roles values(?,?,?)");
					query.setInt(1, userId);
					query.setInt(2, 0);
					query.setString(3, admin);

					return query;
				}
			};

			PreparedStatementCreator roles_user = new PreparedStatementCreator() {

				@Override
				public java.sql.PreparedStatement createPreparedStatement(java.sql.Connection con) throws SQLException {
					java.sql.PreparedStatement query = con.prepareStatement("insert into roles values(?,?,?)");
					query.setInt(1, userId);
					query.setInt(2, 1);
					query.setString(3, roles);

					return query;
				}
			};

			if (user.isRole()) {

				jdbcTemplate.update(updateRegister_True);
				jdbcTemplate.update(roles_admin);
				login.setType("adminreq");

			} else {

				jdbcTemplate.update(updateRegister_false);
				jdbcTemplate.update(roles_user);
				login.setType("user");
			}

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public List<User> readUser() throws SQLException, ClassNotFoundException {

		PreparedStatementCreator readUserQuery = new PreparedStatementCreator() {

			@Override
			public java.sql.PreparedStatement createPreparedStatement(java.sql.Connection con) throws SQLException {
				java.sql.PreparedStatement query = con.prepareStatement("select * from register");
				return query;
			}
		};

		return jdbcTemplate.query(readUserQuery, new UserRowMapper());
	}

	public ArrayList<User> readAdminRequest() {

		PreparedStatementCreator readAdminRequestQuery = new PreparedStatementCreator() {

			@Override
			public java.sql.PreparedStatement createPreparedStatement(java.sql.Connection con) throws SQLException {
				java.sql.PreparedStatement query = con.prepareStatement(
						"select id,firstName from register where id in (select e_id from roles where e_req=0)");
				return query;
			}
		};

		ArrayList<User> list = jdbcTemplate.query(readAdminRequestQuery, new ResultSetExtractor<ArrayList<User>>() {
			public ArrayList<User> extractData(ResultSet resultSetObj) throws SQLException, DataAccessException {
				ArrayList<User> List = new ArrayList<User>();
				while (resultSetObj.next()) {
					User user = new User();
					user.setId(resultSetObj.getInt(1));
					user.setFirstName(resultSetObj.getString(2));
					List.add(user);
				}
				return List;
			}
		});
		return list;

	}

	public boolean checkLogin(Login login) {

		jdbcTemplate.query("select e_role from roles where e_id=" + Integer.parseInt(login.getUserName()),
				(ResultSetExtractor<List<User>>) resultSetObj ->

				{
					List<User> editorList = new ArrayList<User>();
					if (resultSetObj.next()) {
						login.setType(resultSetObj.getString(1));
					}
					return editorList;
				});
		String sql = "SELECT * FROM register WHERE id=" + login.getUserName();
		User user = jdbcTemplate.queryForObject(sql, BeanPropertyRowMapper.newInstance(User.class));
		if (user.getId() == Integer.parseInt(login.getUserName()) && user.getPassword().equals(login.getPassWord())) {
			return true;
		}
		return false;

	}

	public User getUserObject(int id) {

		String sql = "SELECT * FROM register WHERE id=" + id;
		User user = jdbcTemplate.queryForObject(sql, BeanPropertyRowMapper.newInstance(User.class));

		return user;

	}

	public void updateUser(User user) {

		PreparedStatementCreator updateUserQuery = new PreparedStatementCreator() {

			@Override
			public java.sql.PreparedStatement createPreparedStatement(java.sql.Connection con) throws SQLException {
				java.sql.PreparedStatement query = con
						.prepareStatement("update register set firstName=?,lastName=?,email=?,password=?,q1=?,q2=?,q3=? where id=?");
				query.setString(1, user.getFirstName());
				query.setString(2, user.getLastName());
				query.setString(3, user.getEmail());
				query.setString(4, user.getPassword());
				query.setString(5, user.getQ1());
				query.setString(6, user.getQ2());
				query.setString(7, user.getQ3());
				query.setInt(8, user.getId());
				return query;
			}
		};
		jdbcTemplate.update(updateUserQuery);
		return;
	}
	
	public int findUserId(String ques1, String ques2, String ques3) {
		 try {
		 String sql ="select * from register where q1='"+ques1+"' and q2='"+ques2+"' and q3='"+ques3+"' ";
		 User user = jdbcTemplate.queryForObject(sql, BeanPropertyRowMapper.newInstance(User.class));
		 return user.getId();
		 }
		 catch (Exception e) {
		  // TODO: handle exception
		  System.out.print(e);
		 }
		 return 0;

		 }
		 public int findPassword(String username,String ques1, String ques2, String ques3) {
		 try {
		 String sql ="select * from register where id="+username+" and q1='"+ques1+"' and q2='"+ques2+"' and q3='"+ques3+"' ";
		 User user = jdbcTemplate.queryForObject(sql, BeanPropertyRowMapper.newInstance(User.class));
		 return user.getId();
		 }
		 catch (Exception e) {
		  // TODO: handle exception
		  System.out.print(e);
		 }
		 return 0;

		 }


		 public void resetPassword(int userId, String password) {
		 // TODO Auto-generated method stub
		 PreparedStatementCreator creator = new PreparedStatementCreator() {

		  @Override
		  public java.sql.PreparedStatement createPreparedStatement(java.sql.Connection con) throws SQLException {
		  java.sql.PreparedStatement query = con
		   .prepareStatement("update register set password=? where id=?");
		  query.setString(1, password);
		  query.setInt(2,(userId));


		  return query;
		  }
		 };
		 jdbcTemplate.update(creator);
		 return;

		 }

		 public void addAdd(Advertisement add, MultipartFile file, Login login) {
				// TODO Auto-generated method stub
				PreparedStatementCreator addAdverdismentQuery = new PreparedStatementCreator() {

					@Override
					public java.sql.PreparedStatement createPreparedStatement(java.sql.Connection con) throws SQLException {
						java.sql.PreparedStatement query = con.prepareStatement(
								"insert into advertisement(e_id,title,category,field1,field2,image) values(?,?,?,?,?,?)");
						query.setInt(1, Integer.parseInt(login.getUserName()));
						query.setString(2, add.getTitle());
						query.setString(3, add.getCategory());
						query.setString(4, add.getField1());
						query.setString(5, add.getField2());
						try {
							query.setBytes(6, file.getBytes());
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						return query;
					}
				};
				jdbcTemplate.update(addAdverdismentQuery);
			}

	public Advertisement getAddObject(int id) {
		// TODO Auto-generated method stub

		String sql = "SELECT * FROM advertisement WHERE id=" + id;
		Advertisement user = jdbcTemplate.queryForObject(sql, BeanPropertyRowMapper.newInstance(Advertisement.class));
		return user;
	}

	public void addFeedback(String question) {
		// TODO Auto-generated method stub

		PreparedStatementCreator addAdverdismentQuery = new PreparedStatementCreator() {

			@Override
			public java.sql.PreparedStatement createPreparedStatement(java.sql.Connection con) throws SQLException {
				java.sql.PreparedStatement query = con
						.prepareStatement("insert into feedback(question,rating) values(?,?)");
				query.setString(1, question);
				query.setInt(2, -1);
				return query;
			}
		};
		jdbcTemplate.update(addAdverdismentQuery);
	}

	public List<Feedback> getAdminQuestion() {
		// TODO Auto-generated method stub
		PreparedStatementCreator getAdminQuestionQuery = new PreparedStatementCreator() {

			@Override
			public java.sql.PreparedStatement createPreparedStatement(java.sql.Connection con) throws SQLException {
				java.sql.PreparedStatement query = con.prepareStatement("SELECT * FROM feedback");
				return query;
			}
		};

		List<Feedback> list = jdbcTemplate.query(getAdminQuestionQuery,
				BeanPropertyRowMapper.newInstance(Feedback.class));

		return list;
	}

	public void submitFeed(int rating, int id) {

		PreparedStatementCreator submitFeedbackQuery = new PreparedStatementCreator() {

			@Override
			public java.sql.PreparedStatement createPreparedStatement(java.sql.Connection con) throws SQLException {
				java.sql.PreparedStatement query = con.prepareStatement("update feedback set rating=? where id=?");
				query.setInt(1, rating);
				query.setInt(2, id);
				return query;
			}
		};
		jdbcTemplate.update(submitFeedbackQuery);
		return;

	}
	
	
	public List<Advertisement> getAdds(){
		
		String sql = "select * from advertisement";
		List<Advertisement> showServiceCategories = jdbcTemplate.query(sql, new ServiceRowMapper());
		return showServiceCategories;
		

		
	}
	
	




}
