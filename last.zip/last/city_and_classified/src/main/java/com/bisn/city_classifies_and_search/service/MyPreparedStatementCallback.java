
package com.bisn.city_classifies_and_search.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.PreparedStatementCallback;

class MyPreparedStatementCallback implements PreparedStatementCallback<Object> {

	@Override
	public Object doInPreparedStatement(java.sql.PreparedStatement ps) throws SQLException, DataAccessException {
		ResultSet rs = ps.executeQuery();
		List<Long> ids = new LinkedList<Long>();
		while (rs.next()) {
			ids.add(rs.getLong(1));
		}
		rs.close();
		return ids;
	}
}