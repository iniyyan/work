package com.bisn.city_classifies_and_search.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Base64;

import org.springframework.jdbc.core.RowMapper;

import com.bisn.city_classifies_and_search.model.Advertisement;


public class ServiceRowMapper implements RowMapper<Advertisement> {

	@Override
	public Advertisement mapRow(ResultSet result, int rowNumber) throws SQLException {

		Advertisement serviceModel = new Advertisement();
		serviceModel.setId(result.getInt("id"));
		serviceModel.setTitle(result.getString("title"));
		serviceModel.setField1(result.getString("field1"));
		serviceModel.setField2(result.getString("field2"));
		serviceModel.setCategory(result.getString("category"));
		try {
			serviceModel.setFile(getImage(result.getBlob("image")));
		} catch (IOException e) {

			e.getMessage();
		}
		return serviceModel;
	}

	public String getImage(Blob blob) throws SQLException, IOException {

		InputStream inputStream = blob.getBinaryStream();
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		byte[] buffer = new byte[4096];
		int bytesRead = -1;
		while ((bytesRead = inputStream.read(buffer)) != -1) {
			outputStream.write(buffer, 0, bytesRead);
		}
		byte[] imageBytes = outputStream.toByteArray();
		String base64Image = Base64.getEncoder().encodeToString(imageBytes);
		inputStream.close();
		outputStream.close();
		return base64Image;
	}

}