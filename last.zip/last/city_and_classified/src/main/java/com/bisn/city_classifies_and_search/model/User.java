package com.bisn.city_classifies_and_search.model;

import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.bisn.city_classifies_and_search.Annotations.FirstName;
import com.bisn.city_classifies_and_search.Annotations.LastName;

public class User {

	public User() {
	}

	@Min(value = 1, message = "Enter a valid id")
	private int id;
	@NotEmpty(message = "Enter a Valid password")
	private String password;

	private boolean role;
	@FirstName
	@NotEmpty(message = "firstName cannot be empty")
	private String firstName;

	@NotEmpty(message = "lastName cannot be empty")
	@LastName
	private String lastName;

	@Email(message = "email should be valid")
	@NotEmpty(message = "email should be valid")
	private String email;

	@NotEmpty(message = "Answer cannot be empty")
	private String q1;
	@NotEmpty(message = "Answer cannot be empty")
	private String q2;
	@NotEmpty(message = "Answer cannot be empty")
	private String q3;


	public String getQ1() {
		return q1;
	}

	public void setQ1(String q1) {
		this.q1 = q1;
	}

	public String getQ2() {
		return q2;
	}

	public void setQ2(String q2) {
		this.q2 = q2;
	}

	public String getQ3() {
		return q3;
	}

	public void setQ3(String q3) {
		this.q3 = q3;
	}

	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isRole() {
		return role;
	}

	public void setRole(boolean role) {
		this.role = role;
	}

	public User(int id, String firstName, String lastName, String email, boolean role, String password) {
		super();
		this.id = id;

		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.role = role;
		this.password = password;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", role=" + role + ", firstName=" + firstName + ", lastName=" + lastName + ", email="
				+ email + ", password=" + password + ", q1=" + q1 + ", q2=" + q2 + ", q3=" + q3 + "]";
	}


}
