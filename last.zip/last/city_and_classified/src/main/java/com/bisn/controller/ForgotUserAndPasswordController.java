package com.bisn.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.bisn.city_classifies_and_search.service.UserService;



@Controller
@SessionAttributes("id")
public class ForgotUserAndPasswordController {
	@Autowired
	UserService userService;

	@RequestMapping(value = "/forgotUsername", method = RequestMethod.GET)
	public String showForgotUserPage() {
		return "forgotUsername";
	}

	@RequestMapping(value = "/forgotUsername", method = RequestMethod.POST)
	public String showUserId(@RequestParam("Q1") String ques1, @RequestParam("Q2") String ques2,
			@RequestParam("Q3") String ques3, Model model) {
		int flag=0;
		if(ques1.isEmpty()) {
			model.addAttribute("ques1null", "Please answer the question");
			flag=1;
		}
		if(ques2.isEmpty()) {
			model.addAttribute("ques2null", "Please answer the question");
			flag=1;
		}
		if(ques3.isEmpty()) {
			model.addAttribute("ques3null", "Please answer the question");
			flag=1;
		}
		if(flag==0) {
		int id = userService.findUserId(ques1, ques2, ques3);
		if (id == 0) {
			model.addAttribute("error", "Invalid Credentials");
		} else {
			model.addAttribute("UserId", "Your Username: " + id);
		}}

		return "forgotUsername";
	}

	@RequestMapping(value = "/forgotPassword", method = RequestMethod.GET)
	public String showForgotPasswordPage() {
		return "forgotPassword";
	}

	@RequestMapping(value = "/forgotPassword", method = RequestMethod.POST)
	public String showResetPage(@RequestParam("userName") String username, @RequestParam("Q1") String ques1,
			@RequestParam("Q2") String ques2, @RequestParam("Q3") String ques3, Model model) {
		int flag=0;
		if(username.isEmpty()) {
			model.addAttribute("usernull", "Please enter the userId");
			flag=1;
		}
		if(ques1.isEmpty()) {
			model.addAttribute("ques1null", "Please answer the question");
			flag=1;
		}
		if(ques2.isEmpty()) {
			model.addAttribute("ques2null", "Please answer the question");
			flag=1;
		}
		if(ques3.isEmpty()) {
			model.addAttribute("ques3null", "Please answer the question");
			flag=1;
		}if(flag==1) {
			return "forgotPassword";
		}
		int user = userService.findPassword(username, ques1, ques2, ques3);
		if (user == 0) {
			model.addAttribute("error","Invalid Credentials");
			return "forgotPassword";
		} else {
			model.addAttribute("id", user);
			return "resetPassword";
		}
	}

	@RequestMapping(value = "/resetPassword", method = RequestMethod.POST)
	public String resetPassword(@RequestParam("password") String password,@RequestParam("rePassword") String rePassword, Model model) {
		int flag=0;
		if(password=="") {
			model.addAttribute("passwordnull","Enter a valid password");
		    flag=1;	
		}
		 if(rePassword=="") {
			model.addAttribute("repasswordnull", "Enter a valid password");
			flag=1;
		}
		 else if(!rePassword.equals(password)) {
				model.addAttribute("repasswordnull","Enter a matching password");
				flag=1;
			}
		if(flag==1) {
			return "resetPassword";
		}
		
		int userId =   (int) model.getAttribute("id");
		System.out.println(password+" "+userId);
		userService.resetPassword(userId, password);
		return "redirect:/login";
	}
	
}
