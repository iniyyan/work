package com.bisn.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.bisn.city_classifies_and_search.model.Advertisement;
import com.bisn.city_classifies_and_search.model.Feedback;
import com.bisn.city_classifies_and_search.model.Login;
import com.bisn.city_classifies_and_search.model.User;
import com.bisn.city_classifies_and_search.service.UserService;

@SessionAttributes("id")
@Controller
public class DashBoardController {

	@Autowired
	UserService service;

	@RequestMapping(value = "/dashboard", method = RequestMethod.GET)
	public String showLoginPage(@ModelAttribute("add") Advertisement add) {
		return "addAdDash";
	}

	@RequestMapping(value = "/dashboard", method = RequestMethod.POST)
	public String showLogin(@ModelAttribute("add") Advertisement add, @ModelAttribute @Valid Login login,
			BindingResult result, Model model, HttpSession session) {
		if (result.hasErrors()) {
			return "login";
		}

	Decoder decoder = Base64.getDecoder();
	byte[] decodedByte = decoder.decode(login.getPassWord());
		String decodedString = new String(decodedByte);
		login.setPassWord(decodedString);
		System.out.println(decodedString);// Outputs: "Highlight"
		System.out.println(login.getPassWord());
		if (login.getUserName().equals("111111") && login.getPassWord().equals("Root@123")) {
			return "redirect:/superuser";
		}
		boolean checkLogin = service.checkLogin(login);
		 model.addAttribute("login",login);
		model.addAttribute("id", login.getUserName());
		session.setAttribute("login", login);
		if (login.getType().equals("adminreq")) {
			model.addAttribute("invalid","Your admin request is in pending");
			return "login";
		}
		if (login.getType().equals("invalid")) {
			model.addAttribute("invalid","Your admin request is rejected");
			return "login";
		}
		if (checkLogin == false) {
			model.addAttribute("invalid","Invalid Credentials");
			return "login";
		}
		User userObject = service.getUserObject(Integer.parseInt(login.getUserName()));
		session.setAttribute("name", userObject.getFirstName());
		session.setAttribute("userobj", userObject);
		return "addAdDash";
	}

	@GetMapping("/updateUserDash")
	public String showUpdateUserDashPage(@ModelAttribute User user, Model model) {
		// int id = Integer.parseInt((String) model.getAttribute("id"));
		// System.out.println(id);
		// User userObject = service.getUserObject(id);
		// System.out.println(user.toString());
		// model.addAttribute("userobj", userObject);

		return "updateUserDash";
	}

	@PostMapping("/updatedUserDash")
	public String showUpdatedUserDashPage(@ModelAttribute @Valid User user,BindingResult result, Model model, HttpSession session) {
		if (result.hasErrors()) {
			return "updateUserDash";
		}
		service.updateUser(user);
		User userObject = service.getUserObject(user.getId());
		session.setAttribute("userobj", userObject);
		// userObject=user;
		return "updateUserDash";
	}

	@GetMapping("/viewAdDash")
	public String showViewAdDashPage(Model model) {

		List<Advertisement> adds = service.getAdds();
		model.addAttribute("addList", adds);
		System.out.println(adds.toString());
		return "viewAdDash";
	}

	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		System.out.println("Session closed;" + session.getAttribute("login").toString());
		session.invalidate();
		return "redirect:/login";
	}

	@PostMapping("/addAdd")
	public String getAdd(@ModelAttribute("add")@Valid Advertisement add, BindingResult result,@RequestParam("img") MultipartFile file,
			 ModelMap modelMap, HttpSession session) throws IOException {
		if (result.hasErrors()||file.isEmpty()) {
			modelMap.addAttribute("imgnull","Please select a image");
			return "addAdDash";
		}
		System.out.println(add.toString());
		add.setFile(file.toString());
		Login login = (Login) session.getAttribute("login");
		System.out.println(login);
		service.addAdd(add, file, login);
		
		return "addAdDash";
	}

	@GetMapping("/feedback")
	public String getFeedBackPage(HttpSession session, Model model) {
		Login login = (Login) session.getAttribute("login");
		if (login.getType().equals("user")) {
			List<Feedback> adminQuestion = service.getAdminQuestion();
			System.out.println(adminQuestion.toString());
			session.setAttribute("feedback", adminQuestion);
			return "userFeedback";
		} else {
			return "adminFeedback";
		}
	}

	@PostMapping("/addFeedback")
	public String addfeedback(@RequestParam("question") String question,RedirectAttributes redirect) {
       if(question=="") {
    	  redirect.addFlashAttribute("error","Please add feedback questionaries");
    	   return "redirect:/feedback"; 
       }
	   service.addFeedback(question);
		return "adminFeedback";
	}

	@PostMapping("/submitFeedback")
	public String submitFeedback(HttpServletRequest request,Model model,RedirectAttributes redirect) {
		List<String> params = Collections.list(request.getParameterNames());
		

		List<Feedback> adminQuestion = service.getAdminQuestion();
		if(adminQuestion.size()!=params.size()) {
			redirect.addFlashAttribute("error","Please answer for all Questions");
			return "redirect:/feedback";
		}
		
		for (String p : params) {
			
			if(((Integer.parseInt(request.getParameter(p))<=0 || Integer.parseInt(request.getParameter(p))>3))){
				redirect.addFlashAttribute("error","Please answer for all Questions");
				return "userFeedback";
			}
			System.out.println(Integer.parseInt((p)));
			service.submitFeed(Integer.parseInt(request.getParameter(p)), Integer.parseInt(p));
			
			
		}
		
		
		model.addAttribute("success", "Your feedback response have been saved successfully");
		return "userFeedback";
	}

}
