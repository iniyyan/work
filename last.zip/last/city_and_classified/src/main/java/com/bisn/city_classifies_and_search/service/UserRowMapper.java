package com.bisn.city_classifies_and_search.service;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;

import com.bisn.city_classifies_and_search.model.*;

class UserRowMapper implements RowMapper<User> {

	@Autowired
	User user;

	@Override
	public User mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		user.setId(rs.getInt(1));
		user.setFirstName(rs.getString(2));
		user.setLastName(rs.getString(3));
		user.setEmail(rs.getString(4));
		user.setRole(rs.getBoolean(5));
		user.setPassword(rs.getString(6));
		user.setQ1(rs.getString(7));
		user.setQ2(rs.getString(8));
		user.setQ3(rs.getString(9));


		return user;
	}
}