package com.bisn.city_classifies_and_search.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.web.multipart.MultipartFile;

public class Advertisement {
	public Advertisement() {
		super();
	}

	private int id;
@NotEmpty(message="Enter the valid title")
	private String title;
@NotEmpty(message="Enter the valid category")
	private String category;
@NotEmpty(message="Enter the field")
	private String field1;
@NotEmpty(message="Enter the field")
	private String field2;

	private String file;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getField1() {
		return field1;
	}

	public void setField1(String field1) {
		this.field1 = field1;
	}

	public String getField2() {
		return field2;
	}

	public void setField2(String field2) {
		this.field2 = field2;
	}

	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}

	@Override
	public String toString() {
		return "Advertisement [id=" + id + ", title=" + title + ", category=" + category + ", field1=" + field1
				+ ", field2=" + field2 + ", file=" + file + "]";
	}




}
