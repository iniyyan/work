package com.bisn.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class DefaultExceptionHandler  extends ResponseEntityExceptionHandler {
        @ExceptionHandler(value =Exception.class)
        public String exception(Exception exception) {
        	
        	String exceptionType = exception.getClass().getCanonicalName().toString();
        	
        	if(exceptionType.equalsIgnoreCase("java.sql.SQLException")) {
        		return "sqlException";
        	}
        	
        	return "error404";
        }
        
     
}
