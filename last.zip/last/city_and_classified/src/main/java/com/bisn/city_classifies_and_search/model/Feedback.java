package com.bisn.city_classifies_and_search.model;

public class Feedback {

	public Feedback() {	}
	private int id;
	private String question;
	private int rating;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	@Override
	public String toString() {
		return "Feedback [id=" + id + ", question=" + question + ", rating=" + rating + "]";
	}
}
