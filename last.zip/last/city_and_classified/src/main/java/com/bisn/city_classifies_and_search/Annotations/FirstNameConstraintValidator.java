package com.bisn.city_classifies_and_search.Annotations;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class FirstNameConstraintValidator implements ConstraintValidator<FirstName, String> {

	public boolean isValid(String s, ConstraintValidatorContext cvc) {

		return !(s.matches("^\\d"));
	}
}